'''
这是一个初始化包，存储一些用户信息和初始化变量
'''

# 用户信息
api_key = ""
secret_key = ""
passphrase = ""
flag = "0"

# 信息发送渠道
webhook_url = ""