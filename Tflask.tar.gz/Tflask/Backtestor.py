#设置文件路径
import os
import sys
script_directory = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_directory)


import pandas as pd
from Kline import kline_with_signal as ks


class Backtestor:

    def __init__(self, symbol='', strategy_name='', name_dict:dict={}) -> None:
        self.__symbol=symbol
        self.__strategy_name = strategy_name
        self.__nameDict = {
            'datetime':'datetime',
            'open':'open',
            'high':'high',
            'low':'low',
            'close':'close',
            'vol':'vol',
            'signal':'', #原始信号
            'ps':'',
            'ls':'',
            'long_price':'',
            'close_long_price':'',
            'short_price':'',
            'close_short_price':''
        }
        if name_dict:
            for key in self.__nameDict.keys():
                self.__nameDict[key] = name_dict[key]
    
    def factors(self, ohlc:pd.DataFrame):
        return ohlc

    def labels(self, ohlc:pd.DataFrame):
        return ohlc

    def signals(self, ohlc:pd.DataFrame, method=None):
        return ohlc

    def net_value(self, ohlc:pd.DataFrame, store_to:str='', charge:float=0.0):
        return ohlc

    def kline(self, ohlc:pd.DataFrame, store_to:str, name_dict:dict):
        kline_with_signal = ks(name=self.__symbol, strategy=self.__strategy_name, store_to=store_to)
        print(ohlc.columns)
        print(name_dict)
        kline_with_signal.generate(ohlc=ohlc, name_dict=name_dict, bullin=True)

    def backtesting(self, ohlc:pd.DataFrame, netLine='', kline=''):
        data = ohlc.copy()
        data = Backtestor.factors(self, data)
        data = Backtestor.labels(self, data)
        self.__nameDict['ps'] = 'ps'
        self.__nameDict['ls'] = 'ls'
        self.__nameDict['long_price'] = 'open'
        self.__nameDict['close_long_price'] = 'close'
        self.__nameDict['signal'] = 'signal'
        data = Backtestor.signals(self, data)
        data = Backtestor.net_value(self, data, netLine)
        if kline:
            Backtestor.kline(self, ohlc=data, store_to=kline, name_dict=self.__nameDict)
        return data