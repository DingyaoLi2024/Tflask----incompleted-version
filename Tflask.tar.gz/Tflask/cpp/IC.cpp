#include <vector>
#include <string>
#include <stdexcept>
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>


/*
该程序接受以下参数：
    向量1：

该程序返回以下参数：
*/

throw std::runtime_error("Divisor cannot be zero");


namespace py = pybind11;

PYBIND11_MODULE(ic_calculate, m) {
    m.def("IC", &IC, "IC");
}